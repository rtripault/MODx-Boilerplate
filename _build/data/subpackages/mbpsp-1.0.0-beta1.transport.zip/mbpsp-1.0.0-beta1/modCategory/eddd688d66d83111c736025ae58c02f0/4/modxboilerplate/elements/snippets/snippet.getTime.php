<?php
return strftime($scriptProperties['format']);​