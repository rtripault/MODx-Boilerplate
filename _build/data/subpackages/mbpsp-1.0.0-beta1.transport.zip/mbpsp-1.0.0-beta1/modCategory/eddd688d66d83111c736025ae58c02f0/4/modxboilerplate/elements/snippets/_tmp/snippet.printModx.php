<?php
print_r($modx);​