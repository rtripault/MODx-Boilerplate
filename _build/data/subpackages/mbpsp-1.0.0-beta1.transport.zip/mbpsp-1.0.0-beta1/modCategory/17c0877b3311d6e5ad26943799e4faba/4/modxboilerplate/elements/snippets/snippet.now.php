<?php
/*
    Returns actual time in unix timestamp
*/
return time();​