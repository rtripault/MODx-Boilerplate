<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'e7fba70c2c33a2bb7e6cf3dc10bab1e0',
      'native_key' => 'mbpsp',
      'filename' => 'modNamespace/ef0ce62cb461d2421dae3f9592d0560e.vehicle',
      'namespace' => 'mbpsp',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '9dffaffb48afa56ea3d3a395ea9d8836',
      'native_key' => 1,
      'filename' => 'modCategory/17c0877b3311d6e5ad26943799e4faba.vehicle',
      'namespace' => 'mbpsp',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '6eaf7e4b20a69b1c5bb0f45cbe11886b',
      'native_key' => '6eaf7e4b20a69b1c5bb0f45cbe11886b',
      'filename' => 'xPDOTransportVehicle/ab3350f9394e803bbcea143abacd23f8.vehicle',
      'namespace' => 'mbpsp',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => 'a673584c0f35c2bdd21e39e240468aa8',
      'native_key' => 'a673584c0f35c2bdd21e39e240468aa8',
      'filename' => 'xPDOTransportVehicle/6f833500f53576ee5b5098e5fe6e3c1e.vehicle',
      'namespace' => 'mbpsp',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '7d46a2f245c7ddc736363d7925e3371f',
      'native_key' => '7d46a2f245c7ddc736363d7925e3371f',
      'filename' => 'xPDOTransportVehicle/f3153f9929e8df6f5212a75718a8af31.vehicle',
      'namespace' => 'mbpsp',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '9873e142770e3d810024d1f48aef5aec',
      'native_key' => '9873e142770e3d810024d1f48aef5aec',
      'filename' => 'xPDOTransportVehicle/c17f9ada2371eb725316d9c91e2d607e.vehicle',
      'namespace' => 'mbpsp',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '4d56d51195ac8f6e78a1d1b6e1955c80',
      'native_key' => '4d56d51195ac8f6e78a1d1b6e1955c80',
      'filename' => 'xPDOTransportVehicle/96d78c623f5008b3ac00578ee20730c3.vehicle',
      'namespace' => 'mbpsp',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '6458fcfefac3762722effea07704e735',
      'native_key' => '6458fcfefac3762722effea07704e735',
      'filename' => 'xPDOTransportVehicle/fbe96b604c0bd3e6a25ff28a45dc94ac.vehicle',
      'namespace' => 'mbpsp',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => 'e8affb88cd476304d5da09739f95da77',
      'native_key' => 'e8affb88cd476304d5da09739f95da77',
      'filename' => 'xPDOTransportVehicle/8e43bf89b6278c6e5be460668440e543.vehicle',
      'namespace' => 'mbpsp',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => 'f75d7592bdc871c276c78ef7b3a0f1af',
      'native_key' => 'f75d7592bdc871c276c78ef7b3a0f1af',
      'filename' => 'xPDOTransportVehicle/bf786f36e254ec4adff1e0b0ed962a2b.vehicle',
      'namespace' => 'mbpsp',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '618226bda55e33df4049a946af1bfaf2',
      'native_key' => '618226bda55e33df4049a946af1bfaf2',
      'filename' => 'xPDOTransportVehicle/cbf96777809a03f7a387daa9552164ba.vehicle',
      'namespace' => 'mbpsp',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => 'b8ffd79cc11b95dadedd245a207dd400',
      'native_key' => 'b8ffd79cc11b95dadedd245a207dd400',
      'filename' => 'xPDOTransportVehicle/e595bda3d88417c3e64149254d541cf8.vehicle',
      'namespace' => 'mbpsp',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => 'fb6ac0c2a986df492fe69ab51a563841',
      'native_key' => 'fb6ac0c2a986df492fe69ab51a563841',
      'filename' => 'xPDOTransportVehicle/841a5c1bdbe019e3bd0ee0d09a6ab496.vehicle',
      'namespace' => 'mbpsp',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '4f77261b054ce067cd0f96df1abd73f8',
      'native_key' => '4f77261b054ce067cd0f96df1abd73f8',
      'filename' => 'xPDOTransportVehicle/531e7304decb3ea7ac2bd20b59bb53bc.vehicle',
      'namespace' => 'mbpsp',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '15e8f397177dacf52b0b84f230766618',
      'native_key' => '15e8f397177dacf52b0b84f230766618',
      'filename' => 'xPDOTransportVehicle/e60bb1cf75b6ec63a974ed2d488905ed.vehicle',
      'namespace' => 'mbpsp',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '5b2ad5faafbf0261953cd88e274dc07a',
      'native_key' => '5b2ad5faafbf0261953cd88e274dc07a',
      'filename' => 'xPDOTransportVehicle/6711791be9a3833a355556446703e68d.vehicle',
      'namespace' => 'mbpsp',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '3d90428b4149a3f4bf6524d8184ebdd0',
      'native_key' => '3d90428b4149a3f4bf6524d8184ebdd0',
      'filename' => 'xPDOTransportVehicle/15e6c7a4435034f9e9a4b38a657ea12c.vehicle',
      'namespace' => 'mbpsp',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => 'bb440283f6c8b2546d8c23a4f16c5bcc',
      'native_key' => 'bb440283f6c8b2546d8c23a4f16c5bcc',
      'filename' => 'xPDOTransportVehicle/e68fef7a2b561fad2d79999c671cba9d.vehicle',
      'namespace' => 'mbpsp',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '070b62bfa35281e5eebfe871c9f51321',
      'native_key' => '070b62bfa35281e5eebfe871c9f51321',
      'filename' => 'xPDOTransportVehicle/0bbfe8fc7a371cd1514ced186f2ac3a9.vehicle',
      'namespace' => 'mbpsp',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '438dd724732610df7c3121b491950392',
      'native_key' => '438dd724732610df7c3121b491950392',
      'filename' => 'xPDOTransportVehicle/2d4376af29c6ea8b8be9c4a86a0bbdc2.vehicle',
      'namespace' => 'mbpsp',
    ),
  ),
);