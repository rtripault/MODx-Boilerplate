<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'd16b6c1d6c2117178284aa4bd759fa19',
      'native_key' => 'mbpsp',
      'filename' => 'modNamespace/15da804f7c435d3a75e8cfa463fba68e.vehicle',
      'namespace' => 'mbpsp',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '8f5b4a5409f2dc03a7662bc787a6dc60',
      'native_key' => 1,
      'filename' => 'modCategory/eddd688d66d83111c736025ae58c02f0.vehicle',
      'namespace' => 'mbpsp',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '9e6aeab247a9a6e29c64d27d282b3ab3',
      'native_key' => '9e6aeab247a9a6e29c64d27d282b3ab3',
      'filename' => 'xPDOTransportVehicle/19e8a5f691b9f7dd4139a30713d970fd.vehicle',
      'namespace' => 'mbpsp',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '6a4e8c2e12b3ee452639ded819de40fc',
      'native_key' => '6a4e8c2e12b3ee452639ded819de40fc',
      'filename' => 'xPDOTransportVehicle/a7fdbd5cc0ee5861eb8a1a4da1cb90fb.vehicle',
      'namespace' => 'mbpsp',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '1705ac3ab1eb00346d81ac874c8389d3',
      'native_key' => '1705ac3ab1eb00346d81ac874c8389d3',
      'filename' => 'xPDOTransportVehicle/82afc8ec309b06885ed313087501c8c1.vehicle',
      'namespace' => 'mbpsp',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => 'cc5ad4de511e4cf9618d24c542743006',
      'native_key' => 'cc5ad4de511e4cf9618d24c542743006',
      'filename' => 'xPDOTransportVehicle/e47f168f19a9af8a7c880d88d2e59244.vehicle',
      'namespace' => 'mbpsp',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '05ce72eaddbd82f77753d16349bae66d',
      'native_key' => '05ce72eaddbd82f77753d16349bae66d',
      'filename' => 'xPDOTransportVehicle/0f49c5db50528caf400d2e715fdcbd70.vehicle',
      'namespace' => 'mbpsp',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => 'fe59581de3e060c1b44594f5020d00da',
      'native_key' => 'fe59581de3e060c1b44594f5020d00da',
      'filename' => 'xPDOTransportVehicle/762e8ea5736fa56e12c686b68021bc4e.vehicle',
      'namespace' => 'mbpsp',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '2de2929977a38bd741ccfb409c615073',
      'native_key' => '2de2929977a38bd741ccfb409c615073',
      'filename' => 'xPDOTransportVehicle/7959b1cd26134ed428b64945bb7efeca.vehicle',
      'namespace' => 'mbpsp',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '4791d760106e37cf22f67035eca3283e',
      'native_key' => '4791d760106e37cf22f67035eca3283e',
      'filename' => 'xPDOTransportVehicle/f4bcc241af13893fb3e277ebad0b4de6.vehicle',
      'namespace' => 'mbpsp',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '9c8c2ded363abbfc4c592133f3af664a',
      'native_key' => '9c8c2ded363abbfc4c592133f3af664a',
      'filename' => 'xPDOTransportVehicle/3f8418ea692fb239fadd615db7479e21.vehicle',
      'namespace' => 'mbpsp',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '3f182b5f548f38050997087b043f9976',
      'native_key' => '3f182b5f548f38050997087b043f9976',
      'filename' => 'xPDOTransportVehicle/ab0716d5a6fa553359c7b0dd8ee70428.vehicle',
      'namespace' => 'mbpsp',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => 'bc33f9c578cf10aa59187f9cb4b8a4db',
      'native_key' => 'bc33f9c578cf10aa59187f9cb4b8a4db',
      'filename' => 'xPDOTransportVehicle/20da39c6543ff4aa4d2bbd01d25df0a6.vehicle',
      'namespace' => 'mbpsp',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => 'c567c37dddc30e683bff90445fd5195f',
      'native_key' => 'c567c37dddc30e683bff90445fd5195f',
      'filename' => 'xPDOTransportVehicle/a08a7d4010a1fdc98f7d81332b2041c1.vehicle',
      'namespace' => 'mbpsp',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '88e7ab45da977e864f65c08b2d8cf661',
      'native_key' => '88e7ab45da977e864f65c08b2d8cf661',
      'filename' => 'xPDOTransportVehicle/78f6b4d393a506eb7f1cd95b30e1c3b2.vehicle',
      'namespace' => 'mbpsp',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '03ed5ef9fdbd11390c1c02d01726aab5',
      'native_key' => '03ed5ef9fdbd11390c1c02d01726aab5',
      'filename' => 'xPDOTransportVehicle/17c8f81d9e0f2736d49492f0ae254ab1.vehicle',
      'namespace' => 'mbpsp',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '0ed32c7df20f18b94e5d114bf5459468',
      'native_key' => '0ed32c7df20f18b94e5d114bf5459468',
      'filename' => 'xPDOTransportVehicle/28c8191c5ae9b6060448e8e660d9592b.vehicle',
      'namespace' => 'mbpsp',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '320815382603b4e5ae761547cba036c7',
      'native_key' => '320815382603b4e5ae761547cba036c7',
      'filename' => 'xPDOTransportVehicle/a24a7364167eae5bb69f76b32b3708db.vehicle',
      'namespace' => 'mbpsp',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '48fdeefb8739417be68baeceafd77245',
      'native_key' => '48fdeefb8739417be68baeceafd77245',
      'filename' => 'xPDOTransportVehicle/c47ab5649ea3b4b1a534ba41521c4877.vehicle',
      'namespace' => 'mbpsp',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => 'fd1f8c4b3eea94c0da4895ca95685dbf',
      'native_key' => 'fd1f8c4b3eea94c0da4895ca95685dbf',
      'filename' => 'xPDOTransportVehicle/8b72256486386fbb65b469745da88f8e.vehicle',
      'namespace' => 'mbpsp',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => 'f339a42ae1b4d2d1e59e97729d33444f',
      'native_key' => 'f339a42ae1b4d2d1e59e97729d33444f',
      'filename' => 'xPDOTransportVehicle/9762ef5f54ab6e4e376c369aaf2ecca2.vehicle',
      'namespace' => 'mbpsp',
    ),
  ),
);