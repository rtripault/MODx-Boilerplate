<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'e92f40564ea77dd759e63b9f24d11277',
      'native_key' => 'mbpsp',
      'filename' => 'modNamespace/183d5351b58cea2c3f1273f0f2ebcb87.vehicle',
      'namespace' => 'mbpsp',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '1e0db12f68d61dce582da3ee710f7752',
      'native_key' => 1,
      'filename' => 'modCategory/fea427e2d7d697cd54cdba3605fe4f60.vehicle',
      'namespace' => 'mbpsp',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '71482e41dc8fc319d46f52745d4e28d5',
      'native_key' => '71482e41dc8fc319d46f52745d4e28d5',
      'filename' => 'xPDOTransportVehicle/fbd33d42597d1f0c5b274c8f731b0c90.vehicle',
      'namespace' => 'mbpsp',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '0abacbf5b29220741de18c88da5bf9d9',
      'native_key' => '0abacbf5b29220741de18c88da5bf9d9',
      'filename' => 'xPDOTransportVehicle/bfdac087f10044c5fc45b5c7bb4628fb.vehicle',
      'namespace' => 'mbpsp',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '1cfed2ed7cdddf7d77640df6de2b8335',
      'native_key' => '1cfed2ed7cdddf7d77640df6de2b8335',
      'filename' => 'xPDOTransportVehicle/3213ad604c6ac5f331ae35e2d55905d9.vehicle',
      'namespace' => 'mbpsp',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '320ccfba968739f87b69357e431b41ee',
      'native_key' => '320ccfba968739f87b69357e431b41ee',
      'filename' => 'xPDOTransportVehicle/02556d177a6bebfb8fa238c24b77136d.vehicle',
      'namespace' => 'mbpsp',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => 'd96fec6446d42066f8af66d1c594f6cb',
      'native_key' => 'd96fec6446d42066f8af66d1c594f6cb',
      'filename' => 'xPDOTransportVehicle/739c53b6d48c911190dfd3827e04f215.vehicle',
      'namespace' => 'mbpsp',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => 'f544cd0c7a903a1d35d2a8d26c5d7125',
      'native_key' => 'f544cd0c7a903a1d35d2a8d26c5d7125',
      'filename' => 'xPDOTransportVehicle/df1a3247184dc394df44044ab63314f0.vehicle',
      'namespace' => 'mbpsp',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '4618e16d683d3b9b6a33204e22d8099c',
      'native_key' => '4618e16d683d3b9b6a33204e22d8099c',
      'filename' => 'xPDOTransportVehicle/0b5e69c2651597dd84f1143f2722a9dd.vehicle',
      'namespace' => 'mbpsp',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => 'b610dda634206970823e69b15c840b6d',
      'native_key' => 'b610dda634206970823e69b15c840b6d',
      'filename' => 'xPDOTransportVehicle/b3d3a693312a675bb35fe5ce43c89799.vehicle',
      'namespace' => 'mbpsp',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '1394e61b9f6ae5af5163527429c6662d',
      'native_key' => '1394e61b9f6ae5af5163527429c6662d',
      'filename' => 'xPDOTransportVehicle/6d52e9c44a31289382735a0dd371dd6f.vehicle',
      'namespace' => 'mbpsp',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '4e7a56ea880e9369f1e84eabba879b65',
      'native_key' => '4e7a56ea880e9369f1e84eabba879b65',
      'filename' => 'xPDOTransportVehicle/0effbc3a605c38a81353fccbffdf11d8.vehicle',
      'namespace' => 'mbpsp',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '76e83c80a52685283a16697aeb59b371',
      'native_key' => '76e83c80a52685283a16697aeb59b371',
      'filename' => 'xPDOTransportVehicle/904a09d527dcfddde5f6aa9c49b55295.vehicle',
      'namespace' => 'mbpsp',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '46e70e30aa429f7877cf89ed122bd684',
      'native_key' => '46e70e30aa429f7877cf89ed122bd684',
      'filename' => 'xPDOTransportVehicle/5977656503ccbd57a2fb7ec0e22631a4.vehicle',
      'namespace' => 'mbpsp',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '255b907ac60389b040dcd22bbaf64b03',
      'native_key' => '255b907ac60389b040dcd22bbaf64b03',
      'filename' => 'xPDOTransportVehicle/33881a33bf489ea651df3059645d6bc2.vehicle',
      'namespace' => 'mbpsp',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => 'bfaf18ed3dc5d34c2eddedf213cc775e',
      'native_key' => 'bfaf18ed3dc5d34c2eddedf213cc775e',
      'filename' => 'xPDOTransportVehicle/6419465e32cff118c9b500c9de866eb7.vehicle',
      'namespace' => 'mbpsp',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => 'f8dec2e13a9b88010d4d5f8f91b06abe',
      'native_key' => 'f8dec2e13a9b88010d4d5f8f91b06abe',
      'filename' => 'xPDOTransportVehicle/5f0c48784b0950166cdc340533a4c6c7.vehicle',
      'namespace' => 'mbpsp',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '8a609740423dbdde426ebd5ca207875f',
      'native_key' => '8a609740423dbdde426ebd5ca207875f',
      'filename' => 'xPDOTransportVehicle/f5341f0d3e0e9147632579e4ea9c2234.vehicle',
      'namespace' => 'mbpsp',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => 'e0406d3c229ed9e280ed293fd3cb452e',
      'native_key' => 'e0406d3c229ed9e280ed293fd3cb452e',
      'filename' => 'xPDOTransportVehicle/48b2561edce739ce5acc156bb3af6b7b.vehicle',
      'namespace' => 'mbpsp',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => 'c416ef041221467df5a5ffd2d581520d',
      'native_key' => 'c416ef041221467df5a5ffd2d581520d',
      'filename' => 'xPDOTransportVehicle/eae3095548937260c6d6e26e33207f50.vehicle',
      'namespace' => 'mbpsp',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => 'a41f92f0e7fb098fe2ee02de8ad405e1',
      'native_key' => 'a41f92f0e7fb098fe2ee02de8ad405e1',
      'filename' => 'xPDOTransportVehicle/7eefbe8481134efc9766c3534265ef8a.vehicle',
      'namespace' => 'mbpsp',
    ),
  ),
);