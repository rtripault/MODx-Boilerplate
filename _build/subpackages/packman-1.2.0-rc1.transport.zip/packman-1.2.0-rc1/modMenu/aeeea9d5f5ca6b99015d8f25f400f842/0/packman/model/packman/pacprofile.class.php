<?php
/**
 * @package packman
 */
class pacProfile extends xPDOSimpleObject {}
?>