tinyMCE.addI18n('pt.advhr_dlg',{
width:"Largura",
size:"Altura",
noshade:"Sem sombra"
});