tinyMCE.addI18n('zh.advhr_dlg',{
width:"\u5BBD\u5EA6",
size:"\u9AD8\u5EA6",
noshade:"\u65E0\u9634\u5F71"
});