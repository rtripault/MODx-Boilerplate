tinyMCE.addI18n('ro.advhr_dlg',{
width:"L\u0103\u0163ime",
size:"\u00CEn\u0103l\u0163ime",
noshade:"F\u0103r\u0103 umbre"
});