tinyMCE.addI18n('hr.advhr_dlg',{
width:"\u0160irina",
size:"Visina",
noshade:"Bez sjene"
});