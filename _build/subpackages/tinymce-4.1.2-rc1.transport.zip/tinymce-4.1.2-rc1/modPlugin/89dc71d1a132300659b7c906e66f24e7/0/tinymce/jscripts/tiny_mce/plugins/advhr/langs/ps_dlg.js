tinyMCE.addI18n('ps.advhr_dlg',{
width:"Width",
size:"Height",
noshade:"No shadow"
});