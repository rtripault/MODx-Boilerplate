tinyMCE.addI18n('ur.advhr_dlg',{
width:"Width",
size:"Height",
noshade:"No shadow"
});