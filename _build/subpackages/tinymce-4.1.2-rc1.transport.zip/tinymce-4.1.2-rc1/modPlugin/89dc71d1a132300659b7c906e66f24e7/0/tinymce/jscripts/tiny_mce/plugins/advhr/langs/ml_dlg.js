tinyMCE.addI18n('ml.advhr_dlg',{
width:"Width",
size:"Height",
noshade:"No shadow"
});