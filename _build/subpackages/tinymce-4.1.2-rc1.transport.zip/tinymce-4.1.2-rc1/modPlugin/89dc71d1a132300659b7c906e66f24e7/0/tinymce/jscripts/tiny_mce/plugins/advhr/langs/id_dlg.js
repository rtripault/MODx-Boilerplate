tinyMCE.addI18n('id.advhr_dlg',{
width:"Lebar",
size:"Tinggi",
noshade:"Tanpa bayangan"
});