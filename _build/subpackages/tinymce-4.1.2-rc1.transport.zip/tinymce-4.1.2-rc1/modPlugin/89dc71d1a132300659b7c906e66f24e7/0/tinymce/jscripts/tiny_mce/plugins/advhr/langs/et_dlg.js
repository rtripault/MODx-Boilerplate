tinyMCE.addI18n('et.advhr_dlg',{
width:"Laius",
size:"K\u00F5rgus",
noshade:"Ilma varjuta"
});