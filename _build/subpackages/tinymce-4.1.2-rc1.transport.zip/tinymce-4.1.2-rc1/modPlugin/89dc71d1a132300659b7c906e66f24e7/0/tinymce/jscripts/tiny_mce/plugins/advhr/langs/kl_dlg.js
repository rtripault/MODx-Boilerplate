tinyMCE.addI18n('kl.advhr_dlg',{
width:"Width",
size:"Height",
noshade:"No shadow"
});