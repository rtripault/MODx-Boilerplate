tinyMCE.addI18n('vi.advhr_dlg',{
width:"Chi\u1EC1u d\u00E0i",
size:"Chi\u1EC1u r\u1ED9ng",
noshade:"Kh\u00F4ng c\u00F3 b\u00F3ng"
});