tinyMCE.addI18n('da.advhr_dlg',{
width:"Bredde",
size:"H\u00F8jde",
noshade:"Ingen skygge"
});