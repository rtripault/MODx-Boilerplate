--------------------
Extra: CodeMirror
--------------------
Version: 1.0.0
Created: June 23rd, 2010
Author: Shaun McCormick <shaun@modxcms.com>
License: GNU GPLv2 (or later at your option)

Integrates CodeMirror RTE into MODx Revolution.

New in 1.0.0-pl:
- Added plugin properties to adjust how CodeMirror behaves
- Now works on TV default value fields
- Consolidated JS files, fixed too-fast loading in Chrome issue

Please see the documentation at:
http://docs.modxcms.com/display/ADDON/CodeMirror/

Thanks for using CodeMirror!
Shaun McCormick
shaun@modxcms.com