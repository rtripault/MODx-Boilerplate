<?php
setlocale(LC_ALL, 'fr_FR.UTF8');​