<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '92dfc9704f2ed3579b1f03f5dfd95861',
      'native_key' => 'mbp',
      'filename' => 'modNamespace/37e08be948776c318a19761f786b7071.vehicle',
      'namespace' => 'mbp',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '3735de9fff5a58be0ca2b5d45d425fdf',
      'native_key' => 1,
      'filename' => 'modCategory/f5e608fb2834f49430867435bc4a5263.vehicle',
      'namespace' => 'mbp',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => 'd47f91308fb860c690928d2bb11db6bc',
      'native_key' => 'd47f91308fb860c690928d2bb11db6bc',
      'filename' => 'xPDOTransportVehicle/04a7eb1e4a188a887ecaa528efba49f8.vehicle',
      'namespace' => 'mbp',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '10880db00fd6d841581c07066f25f2bd',
      'native_key' => '10880db00fd6d841581c07066f25f2bd',
      'filename' => 'xPDOTransportVehicle/68f792addf2c2908fe11b035314dfe81.vehicle',
      'namespace' => 'mbp',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '780a5612ef8e98c68526a928dc56df86',
      'native_key' => '780a5612ef8e98c68526a928dc56df86',
      'filename' => 'xPDOTransportVehicle/4e611d75660877a215087ac88ac89919.vehicle',
      'namespace' => 'mbp',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => 'c3c38cf78c7dce836568fbb2a2193716',
      'native_key' => 'c3c38cf78c7dce836568fbb2a2193716',
      'filename' => 'xPDOTransportVehicle/1fdf97f439d53c52afb1ff970f243876.vehicle',
      'namespace' => 'mbp',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '43bc2748874a465d191cd64af83ca110',
      'native_key' => '43bc2748874a465d191cd64af83ca110',
      'filename' => 'xPDOTransportVehicle/c1c693940b61c0a0a901daf93fb4cb9e.vehicle',
      'namespace' => 'mbp',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => 'd1af06e2169b56af36ccfe4d7ff33af6',
      'native_key' => 'd1af06e2169b56af36ccfe4d7ff33af6',
      'filename' => 'xPDOTransportVehicle/d5c25481feb53e45d825950f1abd20fb.vehicle',
      'namespace' => 'mbp',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => 'eaee42a8bb4a3c3beafe919b53e3f7b0',
      'native_key' => 'eaee42a8bb4a3c3beafe919b53e3f7b0',
      'filename' => 'xPDOTransportVehicle/4c69d601c1b916f428beed9ed4296a62.vehicle',
      'namespace' => 'mbp',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '1330004826264d2797d00d1c3f393091',
      'native_key' => '1330004826264d2797d00d1c3f393091',
      'filename' => 'xPDOTransportVehicle/348656946cb51bff65246ea5e3d99019.vehicle',
      'namespace' => 'mbp',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => 'f1a098aede5907def67bebdce4b103dc',
      'native_key' => 'f1a098aede5907def67bebdce4b103dc',
      'filename' => 'xPDOTransportVehicle/df145069885df6015cd20dbfd24a6c69.vehicle',
      'namespace' => 'mbp',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => 'de6abeda83f31058de6c4fd01e4136f9',
      'native_key' => 'de6abeda83f31058de6c4fd01e4136f9',
      'filename' => 'xPDOTransportVehicle/a9a6d79d57e1ca2b51ccfa25f899cc61.vehicle',
      'namespace' => 'mbp',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '2bf8a99fff6513fd6a3f16f475b8a3f0',
      'native_key' => '2bf8a99fff6513fd6a3f16f475b8a3f0',
      'filename' => 'xPDOTransportVehicle/b49e140a69b7c511a00820b0ce61a412.vehicle',
      'namespace' => 'mbp',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => 'e58aa2cee64cc38505a6573eb59bb588',
      'native_key' => 'e58aa2cee64cc38505a6573eb59bb588',
      'filename' => 'xPDOTransportVehicle/e08b36520802df1d65fb70e07396adf7.vehicle',
      'namespace' => 'mbp',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => 'e9c61dfa1cde73fe56daa5727a77d0d7',
      'native_key' => 'e9c61dfa1cde73fe56daa5727a77d0d7',
      'filename' => 'xPDOTransportVehicle/72da52dfeac87a4a590695388f2996ec.vehicle',
      'namespace' => 'mbp',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '2927dffec16739a10a8657b3311f8d9f',
      'native_key' => '2927dffec16739a10a8657b3311f8d9f',
      'filename' => 'xPDOTransportVehicle/866f11128ef561bdc017c1682569898d.vehicle',
      'namespace' => 'mbp',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '1a55f503912cf418fe874f0ca5c5a2e8',
      'native_key' => '1a55f503912cf418fe874f0ca5c5a2e8',
      'filename' => 'xPDOTransportVehicle/696b2349e279c3a920cc02d02a5bca94.vehicle',
      'namespace' => 'mbp',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '2bd8d4e01445b75efc10936490682348',
      'native_key' => '2bd8d4e01445b75efc10936490682348',
      'filename' => 'xPDOTransportVehicle/2afb5073b2fe97d814f32c478b723bac.vehicle',
      'namespace' => 'mbp',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '75b437d3248d513cc30407258df8621b',
      'native_key' => '75b437d3248d513cc30407258df8621b',
      'filename' => 'xPDOTransportVehicle/62b9b66e29fbd23094a797f1ede3e946.vehicle',
      'namespace' => 'mbp',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '1428018610274b982491cf0cef808227',
      'native_key' => '1428018610274b982491cf0cef808227',
      'filename' => 'xPDOTransportVehicle/2525f3d08b616fdbe25feb8e66a6d841.vehicle',
      'namespace' => 'mbp',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => 'abbfddbf786dc51e354ce65f13c57567',
      'native_key' => 'abbfddbf786dc51e354ce65f13c57567',
      'filename' => 'xPDOTransportVehicle/a2e2c6f6c7c4ed10445a5ac3af48a889.vehicle',
      'namespace' => 'mbp',
    ),
  ),
);