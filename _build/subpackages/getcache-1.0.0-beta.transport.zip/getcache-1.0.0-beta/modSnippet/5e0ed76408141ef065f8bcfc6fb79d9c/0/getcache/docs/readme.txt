--------------------
Snippet: getCache
--------------------
Version: 1.0.0-beta
Since: October 21, 2010
Author: Jason Coward <jason@modx.com>

A generic caching snippet for caching the output of any MODx Element using a configurable cache handler.

Official Documentation:
http://github.com/opengeek/getCache/wiki