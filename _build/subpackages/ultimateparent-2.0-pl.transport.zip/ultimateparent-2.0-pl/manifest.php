<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'Public Domain',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'd4077b937f944526cfb7036796b16aea',
      'native_key' => 'ultimateparent',
      'filename' => 'modNamespace/996992cdf3ebaab9d2eff04fbb461d27.vehicle',
      'namespace' => 'ultimateparent',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSnippet',
      'guid' => '9bc4b4e6bf331a1137c21a61b9b332a3',
      'native_key' => 1,
      'filename' => 'modSnippet/2ddefb4a8b2beea301c19ddb7ef5dea4.vehicle',
      'namespace' => 'ultimateparent',
    ),
  ),
);